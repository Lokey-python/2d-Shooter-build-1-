import pygame
import random
from tkinter import messagebox

clock = pygame.time.Clock()

count_anim = 0

pygame.init()
screen = pygame.display.set_mode((1200, 600))
pygame.display.set_caption('2d Shooter')

bullet_sound = pygame.mixer.Sound('2dshooter/sounds/shot.mp3')

bullet_img = pygame.image.load('2dshooter/assets/bullet.png').convert_alpha()
bullets = []

kill_cnt = 0

mfont = pygame.font.Font("C:/Users/001.1010401126/Desktop/проэкты/2dshooter/fonts/mono.ttf", 30)
kills = mfont.render(f'Kills: {kill_cnt}', True, 'Red')

icon = pygame.image.load('2dshooter/assets/icon.png').convert_alpha()
pygame.display.set_icon(icon)

enemy_img = pygame.image.load('2dshooter/assets/enemy.png').convert_alpha()
enemys = []

bg_audio = pygame.mixer.Sound('2dshooter/sounds/bg.mp3')
bg_audio.play(-1)

right_anim = [
    pygame.image.load('2dshooter/assets/right/player1.png').convert_alpha(),
    pygame.image.load('2dshooter/assets/right/player2.png').convert_alpha(),
    pygame.image.load('2dshooter/assets/right/player3.png').convert_alpha()
]

player_x = 60
player_y = 450
bg = pygame.image.load('2dshooter/assets/bg.png').convert()
bg_x = 0

is_jump = False
jump_height = 15
gravity = 0.5

timer_enemy = pygame.USEREVENT + 1
pygame.time.set_timer(timer_enemy, 2000)

run = True
while run:

    if kill_cnt == 10:
        messagebox.showinfo('2d shooter', 'Вы победили!')
        pygame.quit()
        break

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not is_jump:
                is_jump = True
            if event.key == pygame.K_c:  
                bullets.append(bullet_img.get_rect(topleft=(player_x + 20, player_y - 10)))
                bullet_sound.play()
        if event.type == timer_enemy:
            enemys.append(enemy_img.get_rect(topleft=(1200, 440)))

    keys = pygame.key.get_pressed()
    if keys[pygame.K_d]:
        player_x += 5
    if keys[pygame.K_a]:
        player_x -= 5

    if player_x < 0:
        player_x = 0
    elif player_x > 1100:
        player_x = 1100

    if is_jump:
        if jump_height >= -15:
            neg = 1
            if jump_height < 0:
                neg = -1
            player_y -= (jump_height ** 2) * 0.05 * neg
            jump_height -= 1
        else:
            is_jump = False
            jump_height = 15
            player_y = 450

    bg_x -= 2
    if bg_x <= -1200:
        bg_x = 0

    
    screen.blit(bg, (bg_x, 0))
    screen.blit(bg, (bg_x + 1200, 0))
    screen.blit(kills, (500, 30))
    screen.blit(right_anim[count_anim // 10], (player_x, player_y))

    player_rect = right_anim[0].get_rect(topleft=(player_x, player_y))

    
    for i, bullet_rect in enumerate(bullets[:]):  
        bullet_rect.x += 5
        screen.blit(bullet_img, bullet_rect)
        if bullet_rect.right > 1200: 
            bullets.pop(i)


    
    for j, enemy_rect in enumerate(enemys[:]):
        enemy_rect.x -= 5
        screen.blit(enemy_img, enemy_rect)

        
        for i, bullet_rect in enumerate(bullets[:]):
            if enemy_rect.colliderect(bullet_rect):
                try:
                  enemys.pop(j)
                  bullets.pop(i)
                  kill_cnt += 1
                  kills = mfont.render(f'Kills: {kill_cnt}', True, 'Red')
                  break  
                except IndexError:
                  pass

        
        if player_rect.colliderect(enemy_rect):
            print('лох умер')
            messagebox.showerror('2d shooter', 'Вы проиграли!')
            run = False
            break  

        
        if enemy_rect.right < 0:
            enemys.pop(j)

    
    count_anim += 1
    if count_anim >= 30:
        count_anim = 0

    pygame.display.update()
    clock.tick(30)

pygame.quit()